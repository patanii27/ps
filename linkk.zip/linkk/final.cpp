#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINES 100
#define MAX_SYMBOLS 50
#define MAX_LITERALS 50

typedef struct {
    int original_address; // Address used in the code
    int opcode;           // Opcode
    int reg_operand;      // Register operand
    int mem_operand;      // Memory operand
} Instruction;

typedef struct {
    char name[20];         // Symbol name
    int original_address;  // Original address defined for the symbol
    int new_address;       // New address after relocation
    char type[10];         // Type of entry (e.g., Symbol, Literal, External)
} Symbol;

typedef struct {
    int original_address;  // Original address for literals
    int new_address;       // New address after relocation
    char value[20];        // Value of the literal
} Literal;

// Symbol definitions with original addresses
Symbol symbols[MAX_SYMBOLS] = {
    {"TEMP_F", 101, 0, "Symbol"},
    {"TEMP_C", 102, 0, "Symbol"},
    {"ENTER_TEMP", 100, 0, "PD"}
};
int symbol_count = 3;

// Literal definitions with original addresses
Literal literals[MAX_LITERALS] = {
    {109, 0, "'9'"},
    {110, 0, "'5'"},
    {111, 0, "'32'"}
};
int literal_count = 3;

int readMachineCode(Instruction instructions[], const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Error: Cannot open file %s\n", filename);
        return -1;
    }
    int count = 0;
    char line[100];

    while (fgets(line, sizeof(line), file) != NULL) {
        int original_address, opcode, reg_operand, mem_operand;
        char reg_str[10], mem_str[10];

        if (sscanf(line, "%d %d %s %s", &original_address, &opcode, mem_str, reg_str) < 4) {
            printf("%s", line);
            continue;
        }

        reg_operand = (strcmp(reg_str, "--") == 0) ? -1 : atoi(reg_str);
        mem_operand = (strcmp(mem_str, "--") == 0) ? -1 : atoi(mem_str);

        instructions[count].original_address = original_address;
        instructions[count].opcode = opcode;
        instructions[count].reg_operand = reg_operand;
        instructions[count].mem_operand = mem_operand;
        count++;

        if (count >= MAX_LINES) {
            break;
        }
    }
    fclose(file);
    return count;
}

void processCode(int link_origin, Instruction instructions[], int count) {
    int translated_origin = 100; // Fixed translated origin
    int relocation_factor = link_origin - translated_origin; // Calculate relocation factor

    printf("\nMachine Code:\n");
    for (int i = 0; i < count; i++) {
        char reg_operand_str[10];
        char mem_operand_str[10];

        // Convert register and memory operands to strings
        if (instructions[i].reg_operand == -1) {
            strcpy(reg_operand_str, "--");
        } else {
            sprintf(reg_operand_str, "%d", instructions[i].reg_operand);
        }

        // Adjust memory operand for relocation, if it is a valid address
        if (instructions[i].mem_operand == -1) {
            strcpy(mem_operand_str, "--");
        } else {
            instructions[i].mem_operand += relocation_factor;
            sprintf(mem_operand_str, "%d", instructions[i].mem_operand);
        }

        printf("%d %d %s %s\n",
               instructions[i].original_address,
               instructions[i].opcode,
               reg_operand_str,
               mem_operand_str);
    }

    printf("\nRelocation Table (RELOCTAB):\n");
    printf("Linked Address\n");
    printf("----------------\n");

    // Update and print relocation table for symbols
    for (int i = 0; i < symbol_count; i++) {
        if (strcmp(symbols[i].type, "PD") == 0) {
            continue;
        }

        int translated_address = translated_origin + symbols[i].original_address - 100; // Adjust translated address
        int linked_address = translated_address + relocation_factor; // Calculate linked address
        symbols[i].new_address = linked_address; // Update symbol's new address
        printf("%d\n", linked_address); // Only print linked address
    }

    // Update and print relocation table for literals
    for (int i = 0; i < literal_count; i++) {
        int translated_address = translated_origin + literals[i].original_address - 100; // Adjust translated address
        int linked_address = translated_address + relocation_factor; // Calculate linked address
        literals[i].new_address = linked_address; // Update literal's new address
        printf("%d\n", linked_address); // Only print linked address
    }

    // Calculate execution start address as the linked address of the first instruction
    int execution_start_address = translated_origin + instructions[0].original_address - 100 + relocation_factor;

    printf("\nHEADER\n");
    printf("Translated Origin: %d\n", translated_origin);
    printf("Execution Start Address of the Program: %d\n", execution_start_address);
    printf("Size (in words): %d\n", count); // Correct size based on actual instruction count

    // Print external references in the link table
    printf("\nLink Table (LINKTAB):\n");
    printf("Symbol         | Type    | Translated Address\n");
    printf("---------------------------------------------\n");

    for (int i = 0; i < symbol_count; i++) {
        if (strcmp(symbols[i].type, "PD") == 0) {
            // Calculate translated address for external symbols correctly
            int translated_address = symbols[i].original_address + translated_origin;
            printf("%-15s | %-7s | %d\n", symbols[i].name, symbols[i].type, translated_address);
        }
    }
}

int main() {
    int link_origin;
    printf("Enter link origin: ");
    if (scanf("%d", &link_origin) != 1) {
        printf("Error: Invalid input.\n");
        return 1;
    }

    Instruction instructions[MAX_LINES];
    int count = readMachineCode(instructions, "machine.txt");
    if (count == -1) {
        return 1;
    }

    processCode(link_origin, instructions, count);
    return 0;
}

