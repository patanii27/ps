#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SYMBOLS 100
#define MAX_CODE 200

// Data Structures
typedef struct {
    char symbol[20];
    int address;
} Symbol;

typedef struct {
    int lc;
    char mnemonic[10];
    char operand1[20];
    char operand2[20];
} IntermediateCode;

// Global Variables
Symbol symbolTable[MAX_SYMBOLS];
IntermediateCode intermediateCode[MAX_CODE];
int symbolCount = 0, icCount = 0, startAddress = 0;

// Function Prototypes
int searchSymbol(const char *symbol);
void generateMachineCode();
void loadInputData(const char *filename);
void error(const char *message);

// Function to Search for Symbol in Symbol Table
int searchSymbol(const char *symbol) {
    for (int i = 0; i < symbolCount; i++) {
        if (strcmp(symbolTable[i].symbol, symbol) == 0) {
            return i;
        }
    }
    return -1;
}

// Function to Load Input Data
void loadInputData(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        error("Unable to open input file.");
        exit(1);
    }

    char line[100];
    int lc = 0;

    // Read the START directive
    if (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "START", 5) == 0) {
            sscanf(line, "START %d", &startAddress);
            lc = startAddress;
        } else {
            error("Missing START directive.");
            exit(1);
        }
    }

    // Read symbols and instructions
    while (fgets(line, sizeof(line), file)) {
        // Trim newline
        line[strcspn(line, "\n")] = '\0';

        if (strcmp(line, "END") == 0) {
            break; // Stop processing at END directive
        }

        char mnemonic[10], operand1[20], operand2[20];
        if (sscanf(line, "%s %s %s", mnemonic, operand1, operand2) >= 1) {
            if (strcmp(mnemonic, "VAR") == 0) {
                // Add to symbol table
                strcpy(symbolTable[symbolCount].symbol, operand1);
                symbolTable[symbolCount].address = lc;
                symbolCount++;
                lc++; // Increment location counter
            } else {
                // Add to intermediate code
                intermediateCode[icCount].lc = lc;
                strcpy(intermediateCode[icCount].mnemonic, mnemonic);
                strcpy(intermediateCode[icCount].operand1, operand1);
                strcpy(intermediateCode[icCount].operand2, operand2);
                icCount++;
                lc++; // Increment location counter
            }
        }
    }

    fclose(file);
}

// Function to Generate Machine Code
void generateMachineCode() {
    FILE *output = fopen("assignment3.txt", "w");
    if (output == NULL) {
        error("Unable to create output file.");
        exit(1);
    }

    fprintf(output, "Machine Code:\n");
    fprintf(output, "LC   Mnemonic  Operand1  Operand2\n");

    for (int i = 0; i < icCount; i++) {
        int symIndex = searchSymbol(intermediateCode[i].operand2);
        fprintf(output, "%d   %-10s %-8s ", 
                intermediateCode[i].lc, 
                intermediateCode[i].mnemonic, 
                intermediateCode[i].operand1);

        if (symIndex != -1) {
            fprintf(output, "%d\n", symbolTable[symIndex].address);
        } else {
            fprintf(output, "%s\n", intermediateCode[i].operand2);
        }
    }

    fclose(output);
}

// Function to Handle Errors
void error(const char *message) {
    printf("Error: %s\n", message);
}

// Main Function
int main() {
    loadInputData("assignment3.asm");
    generateMachineCode();
    printf("Machine code generated in assignment3.txt\n");
    return 0;
}
