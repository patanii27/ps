#include <stdio.h>

int main() {
    printf("SP END SEM");
}